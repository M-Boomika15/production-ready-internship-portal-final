const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { ready, all, get, run } = require("./database");
const { log } = require("./logger");

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

app.use("/api", rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 100,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { status: "error", data: null, error: { code: "RATE_LIMITED", message: "Too many requests. Please try again later." } }
}));

app.use((req, res, next) => {
  const started = Date.now();
  res.on("finish", () => {
    log("info", "http_request", {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - started
    });
  });
  next();
});

app.use(express.static(path.join(__dirname, "public"), {
  etag: true,
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));

const envelope = (status, data, meta = undefined) => {
  const body = { status, data };
  if (meta) body.meta = meta;
  return body;
};
const fail = (res, code, message, httpStatus = 400) =>
  res.status(httpStatus).json({ status: "error", data: null, error: { code, message } });

function parseInternship(row) {
  return { ...row, skills: JSON.parse(row.skills) };
}

app.get("/api/health", async (req, res) => {
  try {
    await ready;
    await get("SELECT 1 AS ok");
    res.status(200).json(envelope("ok", { service: "internship-portal", database: "connected" }));
  } catch (error) {
    log("error", "health_check_failed");
    fail(res, "SERVICE_UNAVAILABLE", "Service is temporarily unavailable.", 503);
  }
});

app.get("/api/internships", async (req, res) => {
  try {
    await ready;
    const q = String(req.query.q || "").trim().slice(0, 80);
    const domain = String(req.query.domain || "").trim().slice(0, 60);
    const mode = String(req.query.mode || "").trim();
    const page = Math.max(1, Math.min(10000, Number.parseInt(req.query.page, 10) || 1));
    const limit = Math.max(1, Math.min(20, Number.parseInt(req.query.limit, 10) || 9));
    if (mode && !["Remote", "Hybrid", "On-site"].includes(mode)) {
      return fail(res, "INVALID_FILTER", "Choose a valid work mode.");
    }

    const conditions = [];
    const params = [];
    if (q) {
      conditions.push("(title LIKE ? OR company LIKE ? OR location LIKE ? OR skills LIKE ?)");
      const term = `%${q.replace(/[\\%_]/g, "\\$&")}%`;
      params.push(term, term, term, term);
    }
    if (domain) { conditions.push("domain = ?"); params.push(domain); }
    if (mode) { conditions.push("mode = ?"); params.push(mode); }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const countRow = await get(`SELECT COUNT(*) AS total FROM internships ${where}`, params);
    const total = countRow.total;
    const pages = Math.max(1, Math.ceil(total / limit));
    const safePage = Math.min(page, pages);
    const rows = await all(
      `SELECT * FROM internships ${where} ORDER BY id ASC LIMIT ? OFFSET ?`,
      [...params, limit, (safePage - 1) * limit]
    );
    res.json(envelope("ok", rows.map(parseInternship), {
      page: safePage, limit, total, pages
    }));
  } catch (error) {
    log("error", "internship_list_failed");
    fail(res, "INTERNAL_ERROR", "Unable to load internships.", 500);
  }
});

app.get("/api/internships/:id", async (req, res) => {
  try {
    await ready;
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return fail(res, "INVALID_ID", "Invalid internship ID.");
    const row = await get("SELECT * FROM internships WHERE id = ?", [id]);
    if (!row) return fail(res, "NOT_FOUND", "Internship not found.", 404);
    res.json(envelope("ok", parseInternship(row)));
  } catch (error) {
    log("error", "internship_detail_failed");
    fail(res, "INTERNAL_ERROR", "Unable to load internship.", 500);
  }
});

function validateApplication(body = {}) {
  const internshipId = Number(body.internship_id);
  const fullName = typeof body.full_name === "string" ? body.full_name.trim() : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const resumeUrl = typeof body.resume_url === "string" ? body.resume_url.trim() : "";

  if (!Number.isSafeInteger(internshipId) || internshipId < 1) return { error: "Select a valid internship." };
  if (fullName.length < 2 || fullName.length > 80 || !/^[\p{L}\p{M} .'-]+$/u.test(fullName)) return { error: "Enter a valid name (2–80 characters)." };
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Enter a valid email address." };
  if (!/^\d{10}$/.test(phone)) return { error: "Phone number must contain exactly 10 digits." };
  if (resumeUrl.length > 2048) return { error: "Resume URL is too long." };

  let parsed;
  try { parsed = new URL(resumeUrl); } catch { return { error: "Enter a valid resume URL." }; }
  if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) {
    return { error: "Resume URL must use HTTP or HTTPS and cannot contain credentials." };
  }
  return { value: { internshipId, fullName, email, phone, resumeUrl } };
}

app.post("/api/applications", async (req, res) => {
  try {
    await ready;
    const safeBody = req.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {};
    const result = validateApplication(safeBody);
    if (result.error) return fail(res, "VALIDATION_ERROR", result.error, 400);
    const { internshipId, fullName, email, phone, resumeUrl } = result.value;
    const internship = await get("SELECT id FROM internships WHERE id = ?", [internshipId]);
    if (!internship) return fail(res, "INTERNSHIP_NOT_FOUND", "The selected internship does not exist.", 404);

    try {
      const inserted = await run(
        `INSERT INTO applications (internship_id, full_name, email, phone, resume_url)
         VALUES (?, ?, ?, ?, ?)`,
        [internshipId, fullName, email, phone, resumeUrl]
      );
      log("info", "application_created", { applicationId: inserted.lastID, internshipId });
      res.status(201).json(envelope("ok", {
        applicationId: inserted.lastID,
        message: "Your application was submitted successfully."
      }));
    } catch (error) {
      if (String(error.message).includes("UNIQUE")) {
        return fail(res, "DUPLICATE_APPLICATION", "You have already applied for this internship with this email.", 409);
      }
      throw error;
    }
  } catch (error) {
    log("error", "application_submission_failed");
    fail(res, "INTERNAL_ERROR", "Unable to submit your application. Please try again.", 500);
  }
});

app.use((req, res) => fail(res, "NOT_FOUND", "The requested resource was not found.", 404));
app.use((error, req, res, next) => {
  log("error", "unhandled_request_error", { errorType: error.name || "Error" });
  if (res.headersSent) return next(error);
  fail(res, "BAD_REQUEST", "The request could not be processed.", 400);
});

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  ready.then(() => {
    app.listen(port, () => log("info", "server_started", { port, environment: process.env.NODE_ENV || "development" }));
  }).catch(() => {
    log("error", "database_initialization_failed");
    process.exit(1);
  });
}

module.exports = app;
