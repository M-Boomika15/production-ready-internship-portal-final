# Production-Ready Internship Portal

A responsive, accessible internship discovery and application portal built with HTML, CSS, JavaScript, Node.js, Express and SQLite.

> **Project status:** Complete starter implementation. Run the commands below and replace the evidence placeholders with your own real test, accessibility, performance, deployment and walkthrough evidence before submission.

## Product features

- Search internship titles, companies, locations and skills.
- Filter by domain and work mode (Remote, Hybrid, On-site).
- Paginated internship results and a detail endpoint.
- Keyboard-operable application dialog with visible focus states.
- Client-side and server-side form validation.
- Duplicate applications blocked per internship and normalized email address.
- Loading, empty, error and retry states.
- Responsive layout designed for 360px mobile screens.
- Reduced-motion support and skip-to-content link.

## Engineering decisions

| Area | Decision | Reason |
|---|---|---|
| Frontend | Semantic HTML, CSS and vanilla JavaScript | Lightweight and easy to maintain |
| Backend | Express REST API | Small, clear API surface |
| Storage | SQLite with parameterized queries | Simple local setup and durable relational data |
| API contract | `{ status, data, meta }` plus structured errors | Predictable client handling |
| Duplicate prevention | Unique database constraint on internship + normalized email | Race-safe enforcement in storage |
| Security | Helmet, request-size limit, rate limiting, validation | Sensible baseline protections |
| Logging | Structured JSON request logs without applicant PII | Operational visibility without logging private records |
| Performance | Small dependency set, indexed filters, static asset caching in production | Reduce unnecessary work and payload |
| Accessibility | Labels, semantic landmarks, skip link, keyboard dialog, focus indicators, reduced motion | Improve keyboard and mobile usability |

## Requirements

- Node.js 18 or newer
- npm
- VS Code or another editor

## Setup

1. Extract the project ZIP.
2. Open the extracted `production-ready-internship-portal` folder in VS Code.
3. Open a terminal in this folder.
4. Install packages:

   ```bash
   npm install
   ```

   In Windows PowerShell, if script execution blocks `npm`, use `npm.cmd install`.

5. Copy `.env.example` to `.env` if you need custom settings. The defaults work locally.
6. Start the app:

   ```bash
   npm start
   ```

   PowerShell alternative: `npm.cmd start`.

7. Visit **http://localhost:3000**.

**Important:** Do not use Live Server on port 5500. The frontend calls the Express API using same-origin paths; use `http://localhost:3000`.

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP server port |
| `NODE_ENV` | `development` | Runtime mode |
| `DB_PATH` | `./data/internships.db` | SQLite database path |
| `LOG_LEVEL` | `info` | `error`, `warn`, `info` or `debug` |

Never commit `.env`, credentials or production data.

## Database and seed data

The database schema and indexes are initialized automatically when the server starts. `seed-data.json` contains five fictional internship records with stable IDs. Seeding runs only when the internship table is empty.

To reset local sample data, stop the server, delete `data/internships.db`, and start the server again. This deletes local applications too.

## API contract

Successful responses:

```json
{
  "status": "ok",
  "data": [],
  "meta": { "page": 1, "limit": 6, "total": 5, "pages": 1 }
}
```

Error responses:

```json
{
  "status": "error",
  "data": null,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Enter a valid email address."
  }
}
```

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Application and database health |
| `GET` | `/api/internships?q=&domain=&mode=&page=&limit=` | Search, filter and paginate |
| `GET` | `/api/internships/:id` | Read one internship |
| `POST` | `/api/applications` | Submit an application |

Application request:

```json
{
  "internship_id": 1,
  "full_name": "Demo Student",
  "email": "student@example.com",
  "phone": "9876543210",
  "resume_url": "https://example.com/resume"
}
```

## Tests

Run:

```bash
npm test
```

PowerShell alternative:

```powershell
npm.cmd test
```

Coverage:

```bash
npm run test:coverage
```

The Jest/Supertest suite uses a temporary SQLite database. It checks health, response shape, pagination, search/filter, invalid input, unsafe URLs, duplicate applications and not-found behavior.

Record your actual terminal output and date in `evidence/test-results.md`. Do not claim a test passed unless the command completed successfully on your machine.

## Quality assurance evidence

Use the supplied checklists:

- `evidence/accessibility-checklist.md`
- `evidence/performance-checklist.md`
- `evidence/security-checklist.md`
- `evidence/test-results.md`

Suggested manual checks:
1. Resize browser to 360px wide and confirm no horizontal page scrolling.
2. Complete the journey using only Tab, Shift+Tab, Enter, Space and Escape.
3. Check labels, focus visibility, dialog close/reopen and error/success messages.
4. Run Lighthouse in Chrome DevTools and record actual Performance, Accessibility, Best Practices and SEO scores.
5. Run tests and inspect server logs. Confirm no email, phone, resume URL, passwords or tokens are logged.

## Deployment

This project can be deployed to a Node.js host that supports persistent storage. Set the start command to `npm start`, configure `PORT`, and ensure the SQLite database path is on persistent storage. Some ephemeral serverless/container filesystems do not preserve SQLite data between restarts; use a managed database for those platforms.

After deployment:
- Visit `/api/health`.
- Submit a test application using synthetic details.
- Confirm the deployed frontend loads and API requests succeed.
- Add the actual deployed URL to `evidence/deployment-and-walkthrough.md`.

## Two-minute walkthrough plan

1. **0:00–0:20** — Introduce the internship portal and responsive home page.
2. **0:20–0:50** — Search, filter by domain/work mode, and navigate pages.
3. **0:50–1:20** — Open a role and submit a valid application using synthetic details.
4. **1:20–1:40** — Show duplicate rejection and API health endpoint.
5. **1:40–2:00** — Show GitHub structure, automated test results and key security decisions.

Record your own walkthrough and add its shareable URL to `evidence/deployment-and-walkthrough.md`.

## Submission

Your one proof link should be the public GitHub repository or a public project page containing:
- Source code
- README and security decisions
- Test output and quality-check evidence
- Deployed application URL
- Walkthrough video URL

Do not publish real applicant data, secrets or unredacted logs.
