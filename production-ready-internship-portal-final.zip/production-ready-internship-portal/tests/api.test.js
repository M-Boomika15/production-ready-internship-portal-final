const path = require("path");
const os = require("os");
const fs = require("fs");

const testDbPath = path.join(os.tmpdir(), `internship-portal-${process.pid}.sqlite`);
process.env.DB_PATH = testDbPath;

const request = require("supertest");
const app = require("../server");
const { ready, db } = require("../database");

describe("Internship portal API", () => {
  beforeAll(async () => { await ready; });

  afterAll(done => {
    db.close(error => {
      try { if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath); } catch (_) {}
      done(error);
    });
  });

  test("health endpoint reports a connected database", async () => {
    const response = await request(app).get("/api/health");
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({ status: "ok", data: { database: "connected" } });
  });

  test("internship list uses predictable envelope and pagination metadata", async () => {
    const response = await request(app).get("/api/internships?page=1&limit=2");
    expect(response.status).toBe(200);
    expect(response.body.status).toBe("ok");
    expect(response.body.data).toHaveLength(2);
    expect(response.body.meta).toMatchObject({ page: 1, limit: 2, total: 5, pages: 3 });
    expect(response.body.data[0].skills).toEqual(expect.arrayContaining(["Linux"]));
  });

  test("search and filters narrow results", async () => {
    const response = await request(app).get("/api/internships?q=Java&mode=Hybrid");
    expect(response.status).toBe(200);
    expect(response.body.data).toHaveLength(1);
    expect(response.body.data[0].title).toBe("Java Developer Intern");
  });

  test("invalid work mode is rejected", async () => {
    const response = await request(app).get("/api/internships?mode=Anywhere");
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe("INVALID_FILTER");
  });

  test("invalid email is rejected", async () => {
    const response = await request(app).post("/api/applications").send({
      internship_id: 1, full_name: "Demo Student", email: "wrong",
      phone: "9876543210", resume_url: "https://example.com/resume"
    });
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe("VALIDATION_ERROR");
  });

  test("unsafe javascript resume URL is rejected", async () => {
    const response = await request(app).post("/api/applications").send({
      internship_id: 1, full_name: "Demo Student", email: "demo@example.com",
      phone: "9876543210", resume_url: "javascript:alert(1)"
    });
    expect(response.status).toBe(400);
  });

  test("valid application is accepted and duplicate is rejected", async () => {
    const payload = {
      internship_id: 1, full_name: "Demo Student", email: "demo@example.com",
      phone: "9876543210", resume_url: "https://example.com/resume"
    };
    const first = await request(app).post("/api/applications").send(payload);
    expect(first.status).toBe(201);
    expect(first.body.data.applicationId).toBeTruthy();

    const duplicate = await request(app).post("/api/applications").send(payload);
    expect(duplicate.status).toBe(409);
    expect(duplicate.body.error.code).toBe("DUPLICATE_APPLICATION");
  });

  test("unknown internship detail returns 404", async () => {
    const response = await request(app).get("/api/internships/9999");
    expect(response.status).toBe(404);
  });
});
