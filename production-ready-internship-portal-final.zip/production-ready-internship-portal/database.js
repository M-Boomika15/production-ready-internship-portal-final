const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const dbPath = process.env.DB_PATH || path.join(__dirname, "data", "internships.db");
if (dbPath !== ":memory:") {
  fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
}

const db = new sqlite3.Database(dbPath);
const seed = require("./seed-data.json");

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (error) {
      if (error) reject(error);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (error, row) => error ? reject(error) : resolve(row));
  });
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows));
  });
}

const ready = (async () => {
  await run("PRAGMA foreign_keys = ON");
  await run(`CREATE TABLE IF NOT EXISTS internships (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    domain TEXT NOT NULL,
    location TEXT NOT NULL,
    mode TEXT NOT NULL CHECK(mode IN ('Remote','Hybrid','On-site')),
    stipend TEXT NOT NULL,
    duration TEXT NOT NULL,
    skills TEXT NOT NULL,
    description TEXT NOT NULL
  )`);
  await run(`CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    internship_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    resume_url TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (internship_id) REFERENCES internships(id),
    UNIQUE (internship_id, email)
  )`);
  const count = await get("SELECT COUNT(*) AS count FROM internships");
  if (count.count === 0) {
    for (const item of seed) {
      await run(
        `INSERT INTO internships
        (id,title,company,domain,location,mode,stipend,duration,skills,description)
        VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [item.id,item.title,item.company,item.domain,item.location,item.mode,item.stipend,
          item.duration,JSON.stringify(item.skills),item.description]
      );
    }
  }
  await run("CREATE INDEX IF NOT EXISTS idx_internships_domain_mode ON internships(domain, mode)");
  await run("CREATE INDEX IF NOT EXISTS idx_applications_email ON applications(email)");
})();

module.exports = { db, ready, run, get, all };
