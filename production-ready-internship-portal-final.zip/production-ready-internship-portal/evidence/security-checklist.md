# Security Evidence Checklist

| Check | Expected result | Actual result |
|---|---|---|
| Invalid email | HTTP 400 | Not run yet |
| Missing/invalid name | HTTP 400 | Not run yet |
| Unsafe `javascript:` resume URL | HTTP 400 | Not run yet |
| Duplicate application | First HTTP 201, repeat HTTP 409 | Not run yet |
| API request rate limit | HTTP 429 after configured threshold | Not run yet |
| Request body limit | Oversized request rejected | Not run yet |
| Logs do not contain applicant PII | No email, phone, resume URL or full body in logs | Not checked yet |
| Security headers | Helmet headers visible in browser Network panel | Not checked yet |

Only test your own local/deployed project. Use synthetic applicant details in screenshots and demonstrations.
