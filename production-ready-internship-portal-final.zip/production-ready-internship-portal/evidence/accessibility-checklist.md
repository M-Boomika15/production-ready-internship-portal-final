# Accessibility Evidence Checklist

Fill this out after testing the running application. Do not mark an item complete until you have checked it.

| Check | How to test | Result / notes |
|---|---|---|
| Keyboard navigation | Use Tab and Shift+Tab through navigation, filters and cards | Not tested yet |
| Skip link | Press Tab immediately after page load; activate “Skip to content” | Not tested yet |
| Application dialog | Open a role with keyboard; use Tab; close with Escape | Not tested yet |
| Form labels | Confirm each input has a visible associated label | Not tested yet |
| Focus visibility | Tab through controls and confirm visible focus ring | Not tested yet |
| Status messages | Trigger loading, no-results, API error and form feedback | Not tested yet |
| 360px layout | Use DevTools responsive mode at 360px width; check no horizontal scrolling | Not tested yet |
| Reduced motion | Enable OS reduced-motion preference and reload | Not tested yet |
| Contrast | Check text and controls using a contrast checker | Not tested yet |

Evidence to attach: screenshots of 360px layout and keyboard focus, plus date and browser version.
