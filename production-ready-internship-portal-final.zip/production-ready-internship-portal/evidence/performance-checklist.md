# Performance Evidence Checklist

## Local manual check

1. Run the app with `npm start`.
2. Open Chrome DevTools → Lighthouse.
3. Run a mobile report for Performance, Accessibility, Best Practices and SEO.
4. Record the actual scores below. Do not invent or estimate scores.
5. Use the Network panel to confirm static assets load and the internship API responds.

| Metric | Actual result |
|---|---|
| Lighthouse Performance (mobile) | Not run yet |
| Lighthouse Accessibility | Not run yet |
| Lighthouse Best Practices | Not run yet |
| Lighthouse SEO | Not run yet |
| `/api/health` response | Not run yet |
| Date / browser | Not recorded |

Performance decisions: small vanilla-JS frontend, no frontend framework, paginated API, database indexes for filters, and production static asset caching.
