# Deployment and Walkthrough

## Deployed application

Status: Not deployed yet  
URL: Add your actual deployed application URL here after deployment.

Health check: `https://YOUR-DEPLOYED-HOST/api/health`  
Replace the example with your real host.

## Walkthrough video

Status: Not recorded yet  
Video URL: Add your actual shareable video URL here.

Suggested two-minute outline is available in the main README.
