const grid = document.getElementById("internshipGrid");
const statusLine = document.getElementById("resultsStatus");
const searchInput = document.getElementById("searchInput");
const domainFilter = document.getElementById("domainFilter");
const modeFilter = document.getElementById("modeFilter");
const retryButton = document.getElementById("retryButton");
const previousButton = document.getElementById("previousPage");
const nextButton = document.getElementById("nextPage");
const pageStatus = document.getElementById("pageStatus");
const dialog = document.getElementById("applicationDialog");
const form = document.getElementById("applicationForm");
const formStatus = document.getElementById("formStatus");
const submitButton = document.getElementById("submitButton");
let page = 1;
let pages = 1;
let searchTimer;

document.getElementById("year").textContent = new Date().getFullYear();

function setStatus(message, type = "") {
  statusLine.textContent = message;
  statusLine.dataset.state = type;
}
function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function addDomains(items) {
  const selected = domainFilter.value;
  const domains = [...new Set(items.map(item => item.domain))].sort();
  domainFilter.replaceChildren(new Option("All domains", ""));
  domains.forEach(domain => domainFilter.add(new Option(domain, domain)));
  if (domains.includes(selected)) domainFilter.value = selected;
}
function openApplication(item) {
  document.getElementById("internshipId").value = item.id;
  document.getElementById("selectedRole").textContent = `${item.title} · ${item.company}`;
  formStatus.textContent = "";
  formStatus.className = "form-status";
  dialog.showModal();
  document.getElementById("fullName").focus();
}
function render(items) {
  grid.replaceChildren();
  if (!items.length) {
    grid.append(make("div", "empty-state", "No internships match your filters. Try a different search or clear the filters."));
    return;
  }
  items.forEach(item => {
    const card = make("article", "role-card");
    const top = make("div", "role-top");
    top.append(make("span", "company-mark", item.company.slice(0, 1).toUpperCase()));
    top.append(make("span", "mode-pill", item.mode));
    card.append(top);
    card.append(make("h3", "", item.title));
    card.append(make("p", "company-name", item.company));
    const meta = make("div", "role-meta");
    meta.append(make("span", "", `⌖ ${item.location}`));
    meta.append(make("span", "", `◷ ${item.duration}`));
    meta.append(make("span", "", item.domain));
    card.append(meta);
    const skills = make("div", "skill-list");
    item.skills.forEach(skill => skills.append(make("span", "skill", skill)));
    card.append(skills);
    const footer = make("div", "role-footer");
    footer.append(make("span", "stipend", item.stipend));
    const button = make("button", "apply-button", "View & apply →");
    button.type = "button";
    button.setAttribute("aria-label", `Apply for ${item.title} at ${item.company}`);
    button.addEventListener("click", () => openApplication(item));
    footer.append(button);
    card.append(footer);
    grid.append(card);
  });
}
async function loadInternships() {
  grid.setAttribute("aria-busy", "true");
  retryButton.hidden = true;
  setStatus("Loading opportunities…");
  const params = new URLSearchParams({ page: String(page), limit: "6" });
  if (searchInput.value.trim()) params.set("q", searchInput.value.trim());
  if (domainFilter.value) params.set("domain", domainFilter.value);
  if (modeFilter.value) params.set("mode", modeFilter.value);

  try {
    const response = await fetch(`/api/internships?${params}`);
    const body = await response.json();
    if (!response.ok || body.status !== "ok") throw new Error(body.error?.message || "Unable to load opportunities.");
    render(body.data);
    pages = body.meta.pages;
    page = body.meta.page;
    addDomains(domainCache.length ? domainCache : body.data);
    previousButton.disabled = page <= 1;
    nextButton.disabled = page >= pages;
    pageStatus.textContent = `Page ${page} of ${pages}`;
    setStatus(`${body.meta.total} ${body.meta.total === 1 ? "opportunity" : "opportunities"} found.`);
    if (body.meta.total === 0) pageStatus.textContent = "No results";
  } catch (error) {
    grid.replaceChildren();
    setStatus(`${error.message} Check your connection and try again.`, "error");
    retryButton.hidden = false;
  } finally {
    grid.setAttribute("aria-busy", "false");
  }
}
let domainCache = [];
async function loadDomains() {
  try {
    const response = await fetch("/api/internships?limit=20");
    const body = await response.json();
    if (response.ok && body.status === "ok") {
      domainCache = body.data;
      addDomains(domainCache);
    }
  } catch (_) {
    // Main list request presents the visible error and retry state.
  }
}
function filtersChanged() {
  page = 1;
  loadInternships();
}
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(filtersChanged, 250);
});
domainFilter.addEventListener("change", filtersChanged);
modeFilter.addEventListener("change", filtersChanged);
document.getElementById("clearFilters").addEventListener("click", () => {
  searchInput.value = "";
  domainFilter.value = "";
  modeFilter.value = "";
  filtersChanged();
});
retryButton.addEventListener("click", loadInternships);
previousButton.addEventListener("click", () => { if (page > 1) { page--; loadInternships(); } });
nextButton.addEventListener("click", () => { if (page < pages) { page++; loadInternships(); } });

document.getElementById("closeDialog").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});
dialog.addEventListener("close", () => document.getElementById("opportunities").querySelector("h2").focus?.());

form.addEventListener("submit", async event => {
  event.preventDefault();
  formStatus.textContent = "";
  formStatus.className = "form-status";
  if (!form.reportValidity()) return;
  const payload = Object.fromEntries(new FormData(form).entries());
  submitButton.disabled = true;
  submitButton.textContent = "Submitting…";
  try {
    const response = await fetch("/api/applications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const body = await response.json();
    if (!response.ok || body.status !== "ok") {
      const error = new Error(body.error?.message || "Your application could not be submitted.");
      error.code = body.error?.code;
      throw error;
    }
    formStatus.textContent = body.data.message;
    formStatus.classList.add("success");
    form.reset();
    setTimeout(() => dialog.close(), 1500);
  } catch (error) {
    formStatus.textContent = error.message;
    formStatus.classList.add("error");
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Submit application <span aria-hidden="true">→</span>';
  }
});

loadDomains().then(loadInternships);
