const levels = { error: 0, warn: 1, info: 2, debug: 3 };
const configuredLevel = process.env.LOG_LEVEL || "info";

function log(level, event, details = {}) {
  if (levels[level] > (levels[configuredLevel] ?? levels.info)) return;
  // Never pass request bodies, email addresses, phone numbers, tokens or credentials here.
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    event,
    ...details
  };
  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else console.log(line);
}

module.exports = { log };
