# Security Notes

## Controls implemented

- Helmet sets common HTTP security headers.
- Express JSON and URL-encoded request bodies are capped at 10 KB.
- API endpoints use rate limiting (100 requests per 15-minute window per client by default).
- Applicant values are validated on the server.
- SQL values are passed as parameters; user input is not concatenated into SQL statements.
- Email addresses are trimmed and normalized to lowercase before insertion.
- A SQLite UNIQUE constraint prevents duplicate applications for the same internship/email pair, including concurrent requests.
- Resume links must parse as HTTP or HTTPS URLs and cannot include embedded credentials.
- The frontend renders database strings with `textContent`, not unsafe HTML interpolation.
- Structured logs include method, path, status, duration and application ID only. They exclude request bodies and applicant contact details.
- `.gitignore` excludes database files, dependencies and environment files.

## Threats and mitigations

| Threat | Mitigation | Verification |
|---|---|---|
| SQL injection | Parameterized SQL | Submit unusual search/form strings and review query code |
| Duplicate submissions | Database unique constraint | Duplicate application test returns HTTP 409 |
| Unsafe URL schemes | URL parser and protocol allowlist | `javascript:` URL test returns HTTP 400 |
| Excessive requests | API rate limiter | Inspect rate-limit configuration |
| Oversized payloads | 10 KB body limit | Send oversized JSON in a local test |
| Sensitive log exposure | Allowlisted structured log fields | Review terminal output during synthetic submission |
| Browser script injection | `textContent` DOM rendering | Review frontend rendering functions |

## Production hardening still required

- Deploy behind HTTPS.
- Use a managed database with backups and access controls for production.
- Add an administrator authentication system before adding applicant-review pages.
- Add privacy notice, retention schedule and deletion process for applicant data.
- Configure trusted proxy settings only for the actual hosting platform.
- Add monitoring/alerting and log retention rules.
- Review rate limits and CORS policy if the frontend/API are hosted on different origins.
- Do not expose database files or applicant records publicly.

This educational project is not a security certification or a substitute for a production security review.
